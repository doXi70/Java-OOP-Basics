package P01_DefineBankAccountClass;

public class BankAccount {
    public int id;
    public double balance;
}
