package p06_RawData;

public class Model {
    private String name;

    public Model(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
