package Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] student = reader.readLine().split(" ");
        String[] worker = reader.readLine().split(" ");
        String firstName = student[0];
        String secondName = student[1];
        String facultyNumber = student[2];
        String firstNames = worker[0];
        String lastName = worker[1];
        Double weekSalary = Double.parseDouble(worker[2]);
        Integer workHoursPerDay = Integer.parseInt(worker[3]);
        try {
            Student students = new Student(facultyNumber, firstName, secondName);
            Worker workers = new Worker(weekSalary, workHoursPerDay, firstNames, lastName);
            System.out.println(students.toString());
            System.out.println(workers.toString());
        } catch (IllegalArgumentException error) {
            System.out.println(error.getMessage());
        }
    }
}

class Human {
    private String firstName;
    private String lastName;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) throws IllegalArgumentException {
        char[] chars = firstName.toCharArray();
        if (Character.isUpperCase(chars[0])) {

            if (firstName.length() >= 4) {
                this.firstName = firstName;
            } else {
                throw new IllegalArgumentException("Expected length at least 4 symbols!Argument: firstName");
            }

        } else {
            throw new IllegalArgumentException("Expected upper case letter!Argument: firstName");
        }
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) throws IllegalArgumentException {
        char[] chars = lastName.toCharArray();
        if (Character.isUpperCase(chars[0])) {

            if (lastName.length() >= 3) {
                this.lastName = lastName;
            } else {
                throw new IllegalArgumentException("Expected length at least 3 symbols!Argument: lastName");
            }

        } else {
            throw new IllegalArgumentException("Expected upper case letter!Argument: lastName");
        }
    }
}

class Student extends Human {
    private String facultyNumber;
    private String firstName;
    private String secondName;

    public Student(String facultyNumber, String firstName, String secondName) {
        this.setFacultyNumber(facultyNumber);
        this.setFirstName(firstName);
        this.setSecondName(secondName);
    }

    @Override
    public String getFirstName() {
        return super.getFirstName();
    }

    @Override
    public void setFirstName(String firstName) {
        super.setFirstName(firstName);
    }

    public String getSecondName() {
        return super.getLastName();
    }

    public void setSecondName(String secondName) {
        super.setLastName(secondName);
    }

    public String getFacultyNumber(String facultyNumber) {
        return facultyNumber;
    }

    public void setFacultyNumber(String facultyNumber) throws IllegalArgumentException {
        char[] test = facultyNumber.toCharArray();
        if (test.length >= 5 && test.length <= 10) {
            this.facultyNumber = facultyNumber;
        } else {
            throw new IllegalArgumentException("Invalid faculty number!");
        }

    }

    @Override
    public String toString() {

        return String.format("First Name: %s%nSecond Name: %s%nFaculty number: %d",
                getFirstName(),
                getSecondName(),
                getFacultyNumber(facultyNumber)
        );
    }
}

class Worker extends Human {
    private Double weekSalary;
    private Integer workHoursPerDay;
    private String firstName;
    private String lastName;
    private Double salaryPerHour;

    public Worker(Double weekSalary, Integer workHoursPerDay, String firstNames, String lastName) {
        this.setWeekSalary(weekSalary);
        this.setWorkHoursPerDay(workHoursPerDay);
        this.setFirstName(firstNames);
        this.setLastName(lastName);
    }

    public Double getWeekSalary() {
        return weekSalary;
    }

    public void setWeekSalary(Double weekSalary) throws IllegalArgumentException {
        if (weekSalary > 10) {
            this.weekSalary = weekSalary;
        } else {
            throw new IllegalArgumentException("Expected value mismatch!Argument: weekSalary");
        }

    }

    public Integer getWorkHoursPerDay() {
        return workHoursPerDay;
    }

    public void setWorkHoursPerDay(Integer workHoursPerDay) throws IllegalArgumentException {
        if (workHoursPerDay >= 1 || workHoursPerDay <= 12) {
            this.workHoursPerDay = workHoursPerDay;
        } else {
            throw new IllegalArgumentException("Expected value mismatch!Argument: workHoursPerDay");
        }
    }

    @Override
    public String getFirstName() {
        return firstName;
    }

    @Override
    public void setFirstName(String firstNames) {
        this.firstName = firstNames;
    }

    @Override
    public String getLastName() {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) throws IllegalArgumentException {

        if (lastName.length() > 3) {
            this.lastName = lastName;
        } else {
            throw new IllegalArgumentException("Expected length more than 3 symbols!Argument: lastName");
        }

    }

    public Double getSalaryPerHour() {
        return salaryPerHour = this.getWeekSalary() / (this.getWorkHoursPerDay() * 7);
    }

    @Override
    public String toString() {

        return String.format("First Name: %s%nSecond Name: %s%nWeek Salary: %.2f%nHours per day: %d%nSalary per hour: %.2f%n",
                getFirstName(),
                getLastName(),
                getWeekSalary(),
                getWorkHoursPerDay(),
                getSalaryPerHour()
        );
    }
}