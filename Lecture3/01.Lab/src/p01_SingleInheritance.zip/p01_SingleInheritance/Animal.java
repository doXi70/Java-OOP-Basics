package p01_SingleInheritance;

public class Animal {

    protected void eat() {
        System.out.println("eating...");
    }
}
