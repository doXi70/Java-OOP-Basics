package p04_FragileBaseClass;

public class Main {
    public static void main(String[] args) {

    }
}
