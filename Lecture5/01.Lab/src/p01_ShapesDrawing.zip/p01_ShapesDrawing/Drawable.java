package p01_ShapesDrawing;

public interface Drawable {
    void draw();
}
