package p03_CarShopExtend;

public interface Sellable extends Car {
    Double getPrice();
}
