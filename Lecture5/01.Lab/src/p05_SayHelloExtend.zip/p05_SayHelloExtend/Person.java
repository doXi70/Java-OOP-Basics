package p05_SayHelloExtend;

public interface Person {

    String getName();

    String sayHello();
}
