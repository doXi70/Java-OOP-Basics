package p02_MultipleImplementation;

public interface Person {

    String getName();

    Integer getAge();
}
