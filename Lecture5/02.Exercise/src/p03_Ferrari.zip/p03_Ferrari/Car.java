package p03_Ferrari;

public interface Car {
    String MODEL = "488-Spider";

    String useBreaks();

    String pushTheGasPedal();
}
