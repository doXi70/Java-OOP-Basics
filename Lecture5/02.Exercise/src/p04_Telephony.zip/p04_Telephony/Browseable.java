package p04_Telephony;

public interface Browseable {
    void browse();
}
