package p05_BorderControl;

public interface BorderControl {
    boolean check(String fakeIdEnd);
}
