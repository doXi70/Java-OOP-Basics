package p06_BirthdayCelebrations;

public interface Birthable {
    boolean checkBirthYear(String year);

    String getBirthdate();
}
