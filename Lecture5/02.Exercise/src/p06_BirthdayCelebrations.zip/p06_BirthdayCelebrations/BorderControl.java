package p06_BirthdayCelebrations;

public interface BorderControl {
    boolean check(String fakeIdEnd);
}
