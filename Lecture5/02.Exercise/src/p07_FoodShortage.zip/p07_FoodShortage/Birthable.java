package p07_FoodShortage;

public interface Birthable {
    boolean checkBirthYear(String year);

    String getBirthdate();
}
