package p07_FoodShortage;

public interface BorderControl {
    boolean check(String fakeIdEnd);
}
