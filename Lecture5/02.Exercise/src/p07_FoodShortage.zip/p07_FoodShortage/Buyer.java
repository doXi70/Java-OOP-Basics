package p07_FoodShortage;

public interface Buyer {
    Integer STARTING_FOOD = 0;

    void buyFood();
    Integer getFood();
}
