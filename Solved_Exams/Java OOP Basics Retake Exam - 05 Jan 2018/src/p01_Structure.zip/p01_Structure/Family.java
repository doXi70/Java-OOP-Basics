package p01_Structure;

public class Family {
    private String id;


    public Family(String id) {
        this.id = id;
    }
}
